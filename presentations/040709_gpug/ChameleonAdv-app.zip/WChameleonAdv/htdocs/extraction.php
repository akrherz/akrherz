<?php
/** simple script to support the ExtractContext widget */
echo "ExtractContext widget passed the following value:<BR>";
echo "<a href=\"".$_GET['CONTEXT']."\">".$_GET['CONTEXT']."</a>";
?>