
// Hardcoded functions to manipulate layers in this sample app.
// These functions rely of Chameleon JavaScript functions to get
// and set DHTML layer properties.


// function to toggle the visibility in a group of layers.
// first layer is made visible, all other layers are hidden.
// arguments array used for layers names

function ToggleLayerSetVis()

{

    var nCount = arguments.length;
    CWCDHTML_SetLayerVis( arguments[0], true );
    eval( "document.forms[0]."+arguments[nCount - 1]+".value='"+arguments[0]+"';" );
    //document.forms[0].TopTabsLayerActive.value = arguments[0];

    var i;
    for( i=1; i<nCount-1; i++ )
    {
        CWCDHTML_SetLayerVis( arguments[i], false );
    }

}

// sets the initial visibility in a group of layers on page draw
// results in persistant layer visibility between page submits.

function LayerSetVisInit()

{

    var activeLayer = document.forms[0].TopTabsLayerActive.value;
    var tmpIndex = activeLayer.indexOf( 'TopTabsLayerActive' );

    if( activeLayer.indexOf( 'TopTabsLayerActive' ) != -1 )
    {
        ToggleLayerSetVis( 'NavToolsLayer', 'ROIToolsLayer', 'TopTabsLayerActive' );
    }
    if( activeLayer.indexOf( 'NavToolsLayer' ) != -1 )
    {
        ToggleLayerSetVis( 'NavToolsLayer', 'ROIToolsLayer', 'TopTabsLayerActive' );
    }
    if( activeLayer.indexOf( 'ROIToolsLayer' ) != -1 )
    {
        ToggleLayerSetVis( 'ROIToolsLayer', 'NavToolsLayer', 'TopTabsLayerActive' );
    }

    var activeLayer = document.forms[0].SideTabsLayerActive.value;
    var tmpIndex = activeLayer.indexOf( 'SideTabsLayerActive' );

    if( activeLayer.indexOf( 'SideTabsLayerActive' ) != -1 )
    {
        ToggleLayerSetVis( 'LegendLayer', 'OtherToolsLayer', 'SideTabsLayerActive' );
    }
    if( activeLayer.indexOf( 'LegendLayer' ) != -1 )
    {
        ToggleLayerSetVis( 'LegendLayer', 'OtherToolsLayer', 'SideTabsLayerActive' );
    }
    if( activeLayer.indexOf( 'OtherToolsLayer' ) != -1 )
    {
        ToggleLayerSetVis( 'OtherToolsLayer', 'LegendLayer', 'SideTabsLayerActive' );
    }

}

// sets the initial size in a group of layers on page draw
// results in layer sizes responding to map size.

function LayerSetSizeInit()

{
    var oImage = CWCDHTML_GetImage( 'mapimage' );
    var imgWidth = oImage.width;
    var imgHeight = oImage.height;

    // MainMapLayer (w+2, h+2)
    var oLayer = CWCDHTML_GetLayer( 'MainMapLayer' );
    oLayer.width = imgWidth + 2;
    oLayer.height = imgHeight + 2;

    // TopTabsLayer (w+20, h)
    var oLayer = CWCDHTML_GetLayer( 'TopTabsLayer' );
    oLayer.width = imgWidth + 20;

    // NavToolsLayer (w+20, h)
    var oLayer = CWCDHTML_GetLayer( 'NavToolsLayer' );
    oLayer.width = imgWidth + 20;

    // ROIToolsLayer (w+20, h)
    var oLayer = CWCDHTML_GetLayer( 'ROIToolsLayer' );
    oLayer.width = imgWidth + 20;

    // PanArrowsLayer (w+20, h)
    var oLayer = CWCDHTML_GetLayer( 'PanArrowsLayer' );
    oLayer.width = imgWidth + 20;
    oLayer.height = imgHeight + 20;

    // ReferenceLayer (w+20, h+22)
    var oLayer = CWCDHTML_GetLayer( 'ReferenceLayer' );
    oLayer.top = 160 + imgHeight;
    oLayer.width = imgWidth + 20;
    
    // LegendLayer (h+20)
    var oLayer = CWCDHTML_GetLayer( 'LegendLayer' );
    oLayer.height = imgHeight + 20;

}

function ShowNavToolsLayer()
{
    ToggleLayerSetVis( 'NavToolsLayer', 'ROIToolsLayer', 'TopTabsLayerActive' );
}

function ShowROIToolsLayer()
{
    ToggleLayerSetVis( 'ROIToolsLayer', 'NavToolsLayer', 'TopTabsLayerActive' );
}

function ShowLegendLayer()
{
    ToggleLayerSetVis( 'LegendLayer', 'OtherToolsLayer', 'SideTabsLayerActive' );
}

function ShowOtherToolsLayer()
{
    ToggleLayerSetVis( 'OtherToolsLayer', 'LegendLayer', 'SideTabsLayerActive' );
}



LayerSetSizeInit();

LayerSetVisInit();
